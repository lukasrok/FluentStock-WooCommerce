<?php return array('version' => '49b04babc5d09eec31c6');
