<?php return array('version' => '27f397bbc5677cdaf9e6');
