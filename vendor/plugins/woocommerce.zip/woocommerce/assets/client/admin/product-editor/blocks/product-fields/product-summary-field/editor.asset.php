<?php return array('version' => '782d1ac5919fb13dd305');
